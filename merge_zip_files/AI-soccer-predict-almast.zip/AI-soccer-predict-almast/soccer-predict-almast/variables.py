available_leagues_filepath = 'database/storage/leagues/available_leagues.csv'
saved_leagues_directory = 'database/storage/leagues/saved/'
models_checkpoint_directory = 'database/storage/checkpoints/'
random_seed = 0
